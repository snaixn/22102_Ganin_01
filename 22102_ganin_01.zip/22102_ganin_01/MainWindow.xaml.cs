﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using _22102_ganin_01.Entity;

namespace _22102_ganin_01
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        private void LoadData()//данныe
        {
            try
            {
                using (var context = new Entities())
                {
                    var students = context.Student.ToList();
                    LoadDataGrid.ItemsSource = students;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки данных: " + ex.Message);
            }
        }
        private void SearchButton_Click(object sender, RoutedEventArgs e)//сортировка, поиск
        {
            try
            {
                using (var context = new Entities())
                {
                    string searchText = SearchTextBox.Text;
                    var allData = context.Student.ToList();
                    var result = allData
                        .Where(d => d.LastName.Contains(searchText));
                    string selectedSort = ((ComboBoxItem)SortComboBox.SelectedItem)?.Content?.ToString();
                    if (selectedSort == null)
                    {
                        MessageBox.Show("Выберите тип сортировки");
                        return;
                    }
                    if (selectedSort == "Сортировка по возрастанию фамилии")
                    {
                        result = result.OrderBy(d => d.FirstName);
                    }
                    else if (selectedSort == "Сортировка по убыванию фамилии")
                    {
                        result = result.OrderByDescending(d => d.FirstName);
                    }
                    if (result.Count() == 0)
                    {
                        MessageBox.Show("Нет результатов");
                    }
                    else
                    {
                        LoadDataGrid.ItemsSource = result.ToList();
                    }
                }
            }
            catch (Exception ex)//ошибка
            {
                MessageBox.Show("Ошибка поиска: " + ex.Message);
            }
        }
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            LoadData();
        }

    }
}